'use strict';

const box = document.querySelector('.box');
const block = document.querySelector('.block');

console.log(block)