'use strict';

const box = document.querySelector('.box');
