import './app.scss';
import Form from './Form';

function App() {
  return (
    <div className="app">
        <Form/>
    </div>
  );
}

export default App;
